import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import { Button } from 'react';
import "./Portfolio.css"



const useStyles = makeStyles((theme) => ({
  mainContainer: {
    background: "#A79B98",
    height: "100%",
  },
  cardContainer: {
    maxWidth: 345,
    margin: "3rem auto",
  },
}));

const projects = [
  {
    name: "Projecto 1",
    description: `TODO List`,
    image: "https://suncatcherstudio.com/uploads/printables/to-do-list/pdf-png/printable-to-do-list-template-1-fefefe-010101.png",
    linkgithub: "https://github.com/tamischnaiderman1/TP02-TODO.git"
  },
  {
    name: "Projecto 2",
    description: `Buscador de películas`,
    image: "https://i0.wp.com/img.culturacolectiva.com/content/2016/04/justwatch-peliculas.png?ssl=1",
    linkgithub: "https://github.com/tamischnaiderman1/TP3_OMDB.git"
  },
  {
    name: "Projecto 3",
    description: `Gestor de Citas`,
    image: "https://www.laycos.net/blog/content/images/2022/02/laycos_blog_cita_previa.jpg",
    linkgithub: "https://github.com/luliwarem/TP04-GestorCitas.git"
  },
  {
    name: "Projecto 4",
    description: `Jugando con Banderas`,
    image: "https://elordenmundial.com/wp-content/uploads/2016/01/banderas-mundo-historia.png",
    linkgithub: "https://github.com/maiaszmedra/TP06-JugandoConBanderas.git"
  },
  {
    name: "Projecto 5",
    description: `Directorio de personas`,
    image: "https://www.makeanet.com/Images/gifs/MiembrosMakeanet.gif",
    linkgithub: "https://github.com/luliwarem/TP07-DirectorioDePersonas.git"
  },
  {
    name: "Projecto 6",
    description: `Catalogo de productos`,
    image: "https://d3vpszern3jgjo.cloudfront.net/wp-content/uploads/2022/11/smartphone-catalog-768x768.jpg",
    linkgithub: "https://github.com/luliwarem/TPCatalogoDeProductos.git"
  },
];

const Portfolio = () => {
  const classes = useStyles();

  return (
    <div className={classes.mainContainer}>
      <div container justify="center">
        {projects.map((project, i) => (
          <div item sm={8} md={4} key={i}>
           {/* <div class="card">
              <img src={project.image} alt="Avatar" style="width:100%"/>
                <div class="container">
                  <h4><b>John Doe</b></h4>
                  <p>Architect & Engineer</p>
                </div>
            </div>*/}
            
            <div className={classes.cardContainer}>
              <div class="card">
              <img className= "card" 
                src={project.image}/>
                <div>
                  <p variant="h5" gutterBottom>
                    {project.name}
                  </p>
                  <p variant="body2" color="textSecondary">
                    {project.description}
                  </p>
                  <button>Ver proyecto</button> 
                  </div> 
              </div>
        
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Portfolio;
